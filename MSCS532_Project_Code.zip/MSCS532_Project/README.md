# MSCS532 Project: Real-Time Ride-Hailing Dispatch

Every time a rider taps "request", a ride-hailing service has to decide
which free driver should go. This project builds the data structures behind
that decision in plain Python.

| Module | Data structure | Role |
| --- | --- | --- |
| `location_grid.py` | Uniform grid of hash buckets (dict of cells → sets) | Keeps track of free drivers and returns the k nearest to a pickup |
| `priority_queue.py` | Indexed binary min-heap | Ranks waiting requests by (tier, request time); cancel and re-rank in O(log n) |
| `road_graph.py` | Directed weighted graph (adjacency dicts) | Driving times via Dijkstra; one backward search ranks several drivers at once |
| `ride_dispatcher.py` | Dictionaries of drivers and requests + the three above | Gives the top request to the driver who can arrive first |

## How one request is assigned

```
request    = waiting.front()                              # O(1)
shortlist  = free_drivers.k_nearest(request.pickup, k)    # visits a few cells
times      = road_graph.travel_times_to(request.pickup, shortlist)  # one backward Dijkstra
driver     = the shortlist entry with the smallest time
free_drivers.remove(driver); waiting.dequeue()            # O(1) avg, O(log n)
```

The grid gives a quick straight-line shortlist, and the road graph then picks
whoever can actually get there first. That matters when a river or a one-way
street makes the closest driver the slowest one.

## Cost of the main operations

| Operation | Time |
| --- | --- |
| Driver GPS update (`LocationGrid.relocate`) | O(1) average |
| Request, cancel, or re-rank a ride | O(log n) |
| k nearest free drivers | O(cells visited + drivers in them) |
| Driving time (Dijkstra with a binary heap) | O((V + E) log V) worst case, stops early |

## Requirements

Python 3.8 or newer. No third-party packages.

## Running

Demo on a 10 × 10 street grid:

```
python3 ride_dispatcher.py
```

Tests:

```
python3 -m unittest -v test_ride_dispatcher
```

The tests check the grid against a scan of every point on random data,
check the queue's heap order and position index after thousands of random
operations, and cover edge cases such as empty structures, duplicate ids,
pickups no driver can reach in time, closed roads, and cancelled requests.
