"""Uniform location grid for finding the free drivers closest to a pickup.

The map is cut into square cells whose side is ``cell_size`` metres. One
dictionary maps every occupied cell (column, row) to the set of driver ids
inside it, and another maps every driver id to its exact (x, y) location.
A GPS update is therefore just a couple of O(1) average-time hash operations,
which matters because each driver reports a new location every few seconds.

To find the k closest drivers, the search looks at the query's own cell and
then at square rings of cells further and further out. Once ring r has been
checked, any driver not yet seen must be at least r * cell_size away, so the
search can stop as soon as the k-th closest distance found is within that
bound. Empty cells are never stored, so memory grows with the number of
drivers rather than with the size of the map.
"""

import heapq
import math


class LocationGrid:
    """Hash-bucketed grid that stores point locations by id."""

    def __init__(self, cell_size):
        if cell_size <= 0:
            raise ValueError("cell_size must be positive")
        self.cell_size = cell_size
        self._buckets = {}     # (column, row) -> set of member ids in that cell
        self._locations = {}   # member id -> (x, y)

    def __len__(self):
        return len(self._locations)

    def __contains__(self, member_id):
        return member_id in self._locations

    def _cell_key(self, x, y):
        return (math.floor(x / self.cell_size), math.floor(y / self.cell_size))

    def location(self, member_id):
        """Return the stored (x, y) of ``member_id``; raise KeyError if absent."""
        return self._locations[member_id]

    def add(self, member_id, x, y):
        """Place ``member_id`` at (x, y). Average O(1)."""
        if member_id in self._locations:
            raise KeyError(f"{member_id!r} is already in the grid")
        self._locations[member_id] = (x, y)
        self._buckets.setdefault(self._cell_key(x, y), set()).add(member_id)

    def _take_from_bucket(self, member_id, cell):
        bucket = self._buckets[cell]
        bucket.discard(member_id)
        if not bucket:
            del self._buckets[cell]   # keep only occupied cells

    def remove(self, member_id):
        """Take ``member_id`` out of the grid. Average O(1)."""
        x, y = self._locations.pop(member_id)
        self._take_from_bucket(member_id, self._cell_key(x, y))

    def relocate(self, member_id, x, y):
        """Record a new location for ``member_id``. Average O(1)."""
        prev_x, prev_y = self._locations[member_id]
        prev_cell, next_cell = self._cell_key(prev_x, prev_y), self._cell_key(x, y)
        self._locations[member_id] = (x, y)
        if prev_cell != next_cell:
            self._take_from_bucket(member_id, prev_cell)
            self._buckets.setdefault(next_cell, set()).add(member_id)

    def _ring_cells(self, center_col, center_row, ring):
        """Yield the cells on the border of the square ``ring`` cells out."""
        if ring == 0:
            yield (center_col, center_row)
            return
        for step in range(-ring, ring + 1):
            yield (center_col + step, center_row - ring)
            yield (center_col + step, center_row + ring)
        for step in range(-ring + 1, ring):
            yield (center_col - ring, center_row + step)
            yield (center_col + ring, center_row + step)

    def k_nearest(self, x, y, k=1, max_distance=math.inf):
        """Return up to ``k`` (distance, id) pairs nearest to (x, y), closest first.

        Members further than ``max_distance`` are ignored. The cost depends on
        how many cells are visited, which stays small when the cell size
        suits the typical search radius.
        """
        if k <= 0 or not self._locations:
            return []
        center_col, center_row = self._cell_key(x, y)
        # No ring beyond the furthest occupied cell (or the distance limit)
        # can contain anything, so the loop below always ends.
        last_ring = max(max(abs(col - center_col), abs(row - center_row))
                        for col, row in self._buckets)
        if max_distance != math.inf:
            last_ring = min(last_ring, int(max_distance // self.cell_size) + 1)

        closest = []  # max-heap of the best k so far, kept as (-distance, id)
        for ring in range(last_ring + 1):
            for cell in self._ring_cells(center_col, center_row, ring):
                for member_id in self._buckets.get(cell, ()):
                    member_x, member_y = self._locations[member_id]
                    distance = math.hypot(member_x - x, member_y - y)
                    if distance > max_distance:
                        continue
                    if len(closest) < k:
                        heapq.heappush(closest, (-distance, member_id))
                    elif distance < -closest[0][0]:
                        heapq.heapreplace(closest, (-distance, member_id))
            # Everything outside rings 0..ring is at least ring * cell_size away.
            if len(closest) == k and -closest[0][0] <= ring * self.cell_size:
                break
        return sorted((-neg_distance, member_id) for neg_distance, member_id in closest)
