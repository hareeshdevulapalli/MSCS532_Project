"""Unit tests for the location grid, priority queue, road graph, and dispatcher."""

import math
import random
import unittest

from location_grid import LocationGrid
from priority_queue import IndexedPriorityQueue
from ride_dispatcher import RideDispatcher, make_grid_city
from road_graph import RoadGraph


class LocationGridTests(unittest.TestCase):
    def nearest_by_scanning_all(self, points, x, y, k, max_distance=math.inf):
        ranked = sorted((math.hypot(px - x, py - y), name) for name, (px, py) in points.items())
        return [entry for entry in ranked if entry[0] <= max_distance][:k]

    def test_empty_grid(self):
        self.assertEqual(LocationGrid(10).k_nearest(0, 0, k=3), [])

    def test_rejects_bad_cell_size_and_duplicates(self):
        with self.assertRaises(ValueError):
            LocationGrid(0)
        grid = LocationGrid(10)
        grid.add("a", 1, 1)
        with self.assertRaises(KeyError):
            grid.add("a", 2, 2)

    def test_agrees_with_full_scan_on_random_points(self):
        rng = random.Random(7)
        for cell_size in (5, 50, 500):
            grid = LocationGrid(cell_size)
            points = {}
            for n in range(300):
                points[f"p{n}"] = (rng.uniform(-1000, 1000), rng.uniform(-1000, 1000))
                grid.add(f"p{n}", *points[f"p{n}"])
            for _ in range(50):
                x, y = rng.uniform(-1200, 1200), rng.uniform(-1200, 1200)
                k = rng.randint(1, 10)
                with self.subTest(cell_size=cell_size, x=x, y=y, k=k):
                    self.assertEqual(grid.k_nearest(x, y, k),
                                     self.nearest_by_scanning_all(points, x, y, k))

    def test_max_distance(self):
        grid = LocationGrid(10)
        grid.add("near", 3, 4)
        grid.add("far", 300, 400)
        self.assertEqual(grid.k_nearest(0, 0, k=5, max_distance=10), [(5.0, "near")])

    def test_relocate_and_remove(self):
        grid = LocationGrid(10)
        grid.add("a", 0, 0)
        grid.add("b", 100, 100)
        grid.relocate("a", 95, 95)
        self.assertEqual(grid.k_nearest(100, 100, k=1)[0][1], "b")
        grid.remove("b")
        self.assertEqual(grid.k_nearest(100, 100, k=1)[0][1], "a")
        grid.remove("a")
        self.assertEqual(len(grid), 0)
        self.assertEqual(grid._buckets, {})  # empty cells are dropped


class IndexedPriorityQueueTests(unittest.TestCase):
    def test_dequeue_order_and_arrival_ties(self):
        queue = IndexedPriorityQueue()
        for key, priority in [("c", 3), ("a", 1), ("b1", 2), ("b2", 2)]:
            queue.enqueue(key, priority)
        self.assertEqual([queue.dequeue()[0] for _ in range(4)], ["a", "b1", "b2", "c"])

    def test_empty_queue_errors(self):
        queue = IndexedPriorityQueue()
        with self.assertRaises(IndexError):
            queue.dequeue()
        with self.assertRaises(IndexError):
            queue.front()
        with self.assertRaises(KeyError):
            queue.cancel("missing")

    def test_duplicate_key_rejected(self):
        queue = IndexedPriorityQueue()
        queue.enqueue("a", 1)
        with self.assertRaises(KeyError):
            queue.enqueue("a", 2)

    def test_random_operations_match_plain_dict(self):
        rng = random.Random(11)
        queue, expected = IndexedPriorityQueue(), {}
        for step in range(3000):
            roll = rng.random()
            if roll < 0.45 or not expected:
                key = f"k{step}"
                priority = rng.randint(0, 100)
                queue.enqueue(key, priority)
                expected[key] = priority
            elif roll < 0.65:
                key = rng.choice(list(expected))
                queue.cancel(key)
                del expected[key]
            elif roll < 0.85:
                key = rng.choice(list(expected))
                expected[key] = rng.randint(0, 100)
                queue.update_priority(key, expected[key])
            else:
                key, priority = queue.dequeue()
                self.assertEqual(priority, min(expected.values()))
                self.assertEqual(expected.pop(key), priority)
            self.assertEqual(len(queue), len(expected))
            for child in range(1, len(queue._slots)):
                self.assertLessEqual(queue._slots[(child - 1) // 2][:2], queue._slots[child][:2])
            for key, slot in queue._slot_of.items():
                self.assertEqual(queue._slots[slot][2], key)


class RoadGraphTests(unittest.TestCase):
    def test_fastest_route_takes_quicker_detour(self):
        graph = RoadGraph()
        for name in "ABCD":
            graph.add_intersection(name, 0, 0)
        graph.add_road("A", "D", 100)
        graph.add_road("A", "B", 20)
        graph.add_road("B", "C", 20)
        graph.add_road("C", "D", 20)
        self.assertEqual(graph.fastest_route("A", "D"), (60, ["A", "B", "C", "D"]))

    def test_one_way_and_closed_roads(self):
        graph = RoadGraph()
        for name in "AB":
            graph.add_intersection(name, 0, 0)
        graph.add_road("A", "B", 10, two_way=False)
        self.assertEqual(graph.fastest_route("A", "B")[0], 10)
        self.assertEqual(graph.fastest_route("B", "A"), (math.inf, []))
        graph.close_road("A", "B", two_way=False)
        self.assertEqual(graph.fastest_route("A", "B"), (math.inf, []))

    def test_bad_input(self):
        graph = RoadGraph()
        graph.add_intersection("A", 0, 0)
        with self.assertRaises(KeyError):
            graph.add_road("A", "Z", 5)
        graph.add_intersection("B", 0, 0)
        with self.assertRaises(ValueError):
            graph.add_road("A", "B", -1)

    def test_travel_times_to_agrees_with_fastest_route(self):
        city = make_grid_city(8, 8)
        starts = [(0, 0), (7, 7), (3, 5), (4, 4)]
        times = city.travel_times_to((4, 4), starts)
        for start in starts:
            self.assertEqual(times[start], city.fastest_route(start, (4, 4))[0])
        self.assertEqual(set(city.travel_times_to((4, 4), starts, limit=100)), {(4, 4), (3, 5)})


class RideDispatcherTests(unittest.TestCase):
    def setUp(self):
        self.city = make_grid_city(10, 10)
        self.dispatcher = RideDispatcher(self.city, cell_size=400.0, shortlist_size=3)

    def test_tier_first_then_request_time(self):
        dispatcher = self.dispatcher
        dispatcher.register_driver("D1", (0, 0))
        dispatcher.register_driver("D2", (9, 9))
        dispatcher.request_ride("late_premium", (1, 1), (2, 2), "premium", 50.0)
        dispatcher.request_ride("early_standard", (8, 8), (2, 2), "standard", 0.0)
        self.assertEqual(dispatcher.assign_next().request_id, "late_premium")
        self.assertEqual(dispatcher.assign_next().request_id, "early_standard")

    def test_chooses_by_driving_time_not_straight_line(self):
        dispatcher = self.dispatcher
        dispatcher.register_driver("across_river", (5, 1))   # 200 m in a straight line
        dispatcher.register_driver("same_bank", (3, 4))      # roughly 630 m away
        # Close every east-west road between columns 4 and 5 except in row 9,
        # so the closer driver must detour around the "river".
        for row in range(9):
            self.city.close_road((4, row), (5, row))
        dispatcher.request_ride("R", (4, 1), (0, 0), "standard", 0.0)
        match = dispatcher.assign_next()
        self.assertEqual((match.driver_id, match.pickup_seconds), ("same_bank", 120))

    def test_cancel_and_unreachable(self):
        dispatcher = RideDispatcher(self.city, shortlist_size=2, max_pickup_seconds=60)
        dispatcher.register_driver("D1", (0, 0))
        dispatcher.request_ride("R1", (9, 9), (0, 0), "standard", 0.0)
        self.assertIsNone(dispatcher.assign_next())   # too far away; stays queued
        self.assertEqual(dispatcher.waiting_total(), 1)
        dispatcher.cancel_ride("R1")
        self.assertEqual(dispatcher.waiting_total(), 0)
        self.assertIsNone(dispatcher.assign_next())

    def test_driver_trip_cycle(self):
        dispatcher = self.dispatcher
        dispatcher.register_driver("D1", (0, 0))
        dispatcher.request_ride("R1", (0, 1), (5, 5), "standard", 0.0)
        match = dispatcher.assign_next()
        self.assertEqual((match.driver_id, match.pickup_seconds), ("D1", 30))
        self.assertEqual(dispatcher.free_driver_total(), 0)
        with self.assertRaises(KeyError):
            dispatcher.update_driver_location("D1", (99, 99))
        dispatcher.finish_trip("D1")
        self.assertEqual(dispatcher.free_driver_total(), 1)
        self.assertEqual(dispatcher.drivers["D1"].location, (5, 5))
        with self.assertRaises(ValueError):
            dispatcher.finish_trip("D1")

    def test_invalid_requests(self):
        dispatcher = self.dispatcher
        with self.assertRaises(ValueError):
            dispatcher.request_ride("R", (0, 0), (1, 1), "luxury", 0.0)
        with self.assertRaises(KeyError):
            dispatcher.request_ride("R", (0, 0), (50, 50), "standard", 0.0)
        dispatcher.request_ride("R", (0, 0), (1, 1), "standard", 0.0)
        with self.assertRaises(KeyError):
            dispatcher.request_ride("R", (0, 0), (1, 1), "standard", 0.0)


if __name__ == "__main__":
    unittest.main()
