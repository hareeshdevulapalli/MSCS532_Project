"""Ride-hailing dispatcher that combines the three core data structures.

* ``drivers`` and ``open_requests`` are dictionaries keyed by id, so any
  driver or request record is found in O(1) average time.
* ``LocationGrid`` holds only the drivers who are free right now and answers
  "which free drivers are nearest this pickup?".
* ``IndexedPriorityQueue`` ranks waiting requests by (tier, request time) and
  lets a rider cancel in O(log n).
* ``RoadGraph`` turns the straight-line shortlist into real driving times.

Assigning one request:
    1. look at the highest-priority request
    2. ask the grid for the k nearest free drivers (fast, approximate)
    3. one backward Dijkstra search from the pickup ranks them by driving time
    4. give the ride to the quickest driver, take them out of the grid,
       and dequeue the request
"""

from dataclasses import dataclass

from location_grid import LocationGrid
from priority_queue import IndexedPriorityQueue
from road_graph import RoadGraph

# Smaller numbers are served first.
TIER_RANK = {"accessible": 0, "premium": 1, "standard": 2}


@dataclass
class Driver:
    driver_id: str
    location: object
    is_free: bool = True
    completed_trips: int = 0


@dataclass
class RideRequest:
    request_id: str
    pickup: object
    dropoff: object
    tier: str
    requested_at: float


@dataclass
class Match:
    request_id: str
    driver_id: str
    pickup_seconds: float


class RideDispatcher:
    """Pairs waiting riders with nearby free drivers."""

    def __init__(self, road_graph, cell_size=500.0, shortlist_size=5, max_pickup_seconds=900):
        if not isinstance(road_graph, RoadGraph):
            raise TypeError("road_graph must be a RoadGraph")
        self.road_graph = road_graph
        self.shortlist_size = shortlist_size
        self.max_pickup_seconds = max_pickup_seconds
        self.drivers = {}
        self.open_requests = {}
        self._free_drivers = LocationGrid(cell_size)
        self._waiting = IndexedPriorityQueue()

    # ----- drivers -----------------------------------------------------

    def register_driver(self, driver_id, location):
        if driver_id in self.drivers:
            raise KeyError(f"driver {driver_id!r} already registered")
        self._check_intersection(location)
        self.drivers[driver_id] = Driver(driver_id, location)
        self._free_drivers.add(driver_id, *self.road_graph.position(location))

    def update_driver_location(self, driver_id, location):
        """Apply a GPS update; free drivers are moved to their new grid cell."""
        self._check_intersection(location)
        driver = self.drivers[driver_id]
        driver.location = location
        if driver.is_free:
            self._free_drivers.relocate(driver_id, *self.road_graph.position(location))

    def finish_trip(self, driver_id):
        """The driver has dropped off the rider and is free where they stopped."""
        driver = self.drivers[driver_id]
        if driver.is_free:
            raise ValueError(f"driver {driver_id!r} is not on a trip")
        driver.is_free = True
        driver.completed_trips += 1
        self._free_drivers.add(driver_id, *self.road_graph.position(driver.location))

    def free_driver_total(self):
        return len(self._free_drivers)

    # ----- requests ----------------------------------------------------

    def request_ride(self, request_id, pickup, dropoff, tier, requested_at):
        if request_id in self.open_requests:
            raise KeyError(f"request {request_id!r} already exists")
        if tier not in TIER_RANK:
            raise ValueError(f"unknown tier {tier!r}")
        self._check_intersection(pickup)
        self._check_intersection(dropoff)
        self.open_requests[request_id] = RideRequest(request_id, pickup, dropoff, tier, requested_at)
        self._waiting.enqueue(request_id, (TIER_RANK[tier], requested_at))

    def cancel_ride(self, request_id):
        self._waiting.cancel(request_id)
        del self.open_requests[request_id]

    def waiting_total(self):
        return len(self._waiting)

    # ----- matching ----------------------------------------------------

    def assign_next(self):
        """Match the top request with a driver, or return None if nobody can go.

        If no free driver can reach the pickup in time, the request stays queued.
        """
        if not self._waiting:
            return None
        request_id, _ = self._waiting.front()
        request = self.open_requests[request_id]
        pickup_x, pickup_y = self.road_graph.position(request.pickup)

        shortlist = self._free_drivers.k_nearest(pickup_x, pickup_y, k=self.shortlist_size)
        drivers_at = {}
        for _, driver_id in shortlist:
            drivers_at.setdefault(self.drivers[driver_id].location, []).append(driver_id)
        drive_times = self.road_graph.travel_times_to(
            request.pickup, drivers_at, limit=self.max_pickup_seconds)
        if not drive_times:
            return None

        quickest = min(drive_times, key=drive_times.get)
        chosen_id = min(drivers_at[quickest])  # same tie-break every run
        chosen = self.drivers[chosen_id]
        chosen.is_free = False
        chosen.location = request.dropoff  # where the driver ends up after the trip
        self._free_drivers.remove(chosen_id)
        self._waiting.dequeue()
        del self.open_requests[request_id]
        return Match(request_id, chosen_id, drive_times[quickest])

    def _check_intersection(self, intersection):
        if intersection not in self.road_graph:
            raise KeyError(f"unknown intersection {intersection!r}")


def make_grid_city(columns, rows, block_length=200.0, seconds_per_block=30.0):
    """Return a RoadGraph laid out as a ``columns`` x ``rows`` street grid.

    Intersections are named (column, row). Useful for the demo and the tests.
    """
    city = RoadGraph()
    for col in range(columns):
        for row in range(rows):
            city.add_intersection((col, row), col * block_length, row * block_length)
    for col in range(columns):
        for row in range(rows):
            if col + 1 < columns:
                city.add_road((col, row), (col + 1, row), seconds_per_block)
            if row + 1 < rows:
                city.add_road((col, row), (col, row + 1), seconds_per_block)
    return city


if __name__ == "__main__":
    city = make_grid_city(10, 10)
    dispatcher = RideDispatcher(city, cell_size=400.0, shortlist_size=3)
    for driver_id, start in [("D1", (0, 0)), ("D2", (5, 5)), ("D3", (9, 9)), ("D4", (2, 7))]:
        dispatcher.register_driver(driver_id, start)

    dispatcher.request_ride("R1", (4, 4), (8, 1), "standard", requested_at=0.0)
    dispatcher.request_ride("R2", (1, 1), (6, 6), "standard", requested_at=5.0)
    dispatcher.request_ride("R3", (9, 8), (0, 9), "accessible", requested_at=9.0)
    dispatcher.request_ride("R4", (3, 3), (3, 9), "premium", requested_at=12.0)
    dispatcher.cancel_ride("R2")

    print(f"{dispatcher.free_driver_total()} free drivers, "
          f"{dispatcher.waiting_total()} waiting requests (R2 was cancelled)")
    while dispatcher.waiting_total():
        match = dispatcher.assign_next()
        if match is None:
            print("no driver can reach the next request in time")
            break
        print(f"{match.request_id} -> {match.driver_id} "
              f"(pickup in {match.pickup_seconds:.0f} s)")

    seconds, route = city.fastest_route((0, 0), (3, 2))
    print(f"fastest route (0,0) -> (3,2): {seconds:.0f} s through {len(route)} intersections")
