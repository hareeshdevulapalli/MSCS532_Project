"""Directed, weighted road graph with Dijkstra-based travel times.

Each intersection is a vertex and each road segment is a directed edge whose
weight is the time in seconds to drive it. A city's road network is sparse
(an intersection joins only a few roads), so edges live in adjacency
dictionaries: O(V + E) memory and O(1) average time to add, re-time, or close
a road.

The graph keeps incoming edges as well as outgoing ones. When several nearby
drivers are competing for one pickup, the dispatcher runs a single Dijkstra
search *backwards* from the pickup and stops once all of them are reached,
instead of starting a separate search from every driver.
"""

import heapq
import math


class RoadGraph:
    """Sparse directed graph of intersections and timed road segments."""

    def __init__(self):
        self._position = {}    # intersection -> (x, y)
        self._outgoing = {}    # intersection -> {next intersection: seconds}
        self._incoming = {}    # intersection -> {previous intersection: seconds}

    def __contains__(self, intersection):
        return intersection in self._position

    def __len__(self):
        return len(self._position)

    def intersections(self):
        return self._position.keys()

    def position(self, intersection):
        return self._position[intersection]

    def add_intersection(self, intersection, x, y):
        if intersection in self._position:
            raise KeyError(f"intersection {intersection!r} already exists")
        self._position[intersection] = (x, y)
        self._outgoing[intersection] = {}
        self._incoming[intersection] = {}

    def add_road(self, start, end, seconds, two_way=True):
        """Add or re-time the segment start -> end (and end -> start if ``two_way``)."""
        if start not in self._position or end not in self._position:
            raise KeyError("both intersections must exist before adding a road")
        if seconds < 0:
            raise ValueError("travel time cannot be negative")
        self._outgoing[start][end] = seconds
        self._incoming[end][start] = seconds
        if two_way:
            self._outgoing[end][start] = seconds
            self._incoming[start][end] = seconds

    def close_road(self, start, end, two_way=True):
        """Remove the segment start -> end, e.g. for a crash or road works."""
        del self._outgoing[start][end]
        del self._incoming[end][start]
        if two_way:
            del self._outgoing[end][start]
            del self._incoming[start][end]

    def fastest_route(self, origin, destination):
        """Return (seconds, [intersections]) for the quickest route, or (inf, []).

        Dijkstra's algorithm on a binary heap with lazy deletion of outdated
        entries: O((V + E) log V) in the worst case, but it returns as soon
        as ``destination`` is settled.
        """
        best_time = {origin: 0}
        came_from = {origin: None}
        to_visit = [(0, origin)]
        while to_visit:
            elapsed, here = heapq.heappop(to_visit)
            if here == destination:
                route = []
                while here is not None:
                    route.append(here)
                    here = came_from[here]
                return elapsed, route[::-1]
            if elapsed > best_time[here]:
                continue  # outdated entry; a faster time was found later
            for neighbour, seconds in self._outgoing[here].items():
                arrival = elapsed + seconds
                if arrival < best_time.get(neighbour, math.inf):
                    best_time[neighbour] = arrival
                    came_from[neighbour] = here
                    heapq.heappush(to_visit, (arrival, neighbour))
        return math.inf, []

    def travel_times_to(self, destination, origins, limit=math.inf):
        """Return {origin: seconds to drive to ``destination``} for reachable origins.

        A single Dijkstra search over incoming edges, starting at
        ``destination``. It ends when every origin is settled or once times
        exceed ``limit``.
        """
        still_needed = set(origins)
        found = {}
        best_time = {destination: 0}
        to_visit = [(0, destination)]
        while to_visit and still_needed:
            elapsed, here = heapq.heappop(to_visit)
            if elapsed > best_time[here]:
                continue
            if elapsed > limit:
                break
            if here in still_needed:
                still_needed.discard(here)
                found[here] = elapsed
            for previous, seconds in self._incoming[here].items():
                arrival = elapsed + seconds
                if arrival < best_time.get(previous, math.inf):
                    best_time[previous] = arrival
                    heapq.heappush(to_visit, (arrival, previous))
        return found
