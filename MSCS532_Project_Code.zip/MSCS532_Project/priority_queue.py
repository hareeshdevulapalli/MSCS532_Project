"""Indexed priority queue (binary min-heap) for ride requests that are waiting.

The standard ``heapq`` module has no way to delete or re-rank an entry in the
middle of the heap short of an O(n) scan. Riders cancel, and requests can be
bumped up the queue, so this queue also keeps a dictionary that records where
each key currently sits in the heap array. That makes enqueue, dequeue,
cancel, and update_priority all O(log n), and looking up a key's priority O(1).

Priorities are compared as tuples, so a request can be ranked by
(service tier, request time); equal priorities leave in the order they arrived.
"""

import itertools


class IndexedPriorityQueue:
    """Min-priority queue whose entries can be located and changed by key."""

    def __init__(self):
        self._slots = []        # heap array of [priority, arrival_no, key]
        self._slot_of = {}      # key -> index of its entry in self._slots
        self._arrivals = itertools.count()

    def __len__(self):
        return len(self._slots)

    def __contains__(self, key):
        return key in self._slot_of

    def priority_of(self, key):
        """Return the current priority of ``key``; raise KeyError if absent."""
        return self._slots[self._slot_of[key]][0]

    def enqueue(self, key, priority):
        """Add ``key`` with ``priority``. O(log n)."""
        if key in self._slot_of:
            raise KeyError(f"{key!r} is already queued")
        self._slots.append([priority, next(self._arrivals), key])
        self._slot_of[key] = len(self._slots) - 1
        self._bubble_up(len(self._slots) - 1)

    def front(self):
        """Return (key, priority) of the smallest entry without removing it. O(1)."""
        if not self._slots:
            raise IndexError("front of an empty queue")
        priority, _, key = self._slots[0]
        return key, priority

    def dequeue(self):
        """Remove and return (key, priority) of the smallest entry. O(log n)."""
        if not self._slots:
            raise IndexError("dequeue from an empty queue")
        priority, _, key = self._slots[0]
        self._delete_slot(0)
        return key, priority

    def cancel(self, key):
        """Delete ``key`` from wherever it sits in the heap. O(log n)."""
        self._delete_slot(self._slot_of[key])

    def update_priority(self, key, priority):
        """Raise or lower the priority of ``key``. O(log n)."""
        slot = self._slot_of[key]
        previous = self._slots[slot][0]
        self._slots[slot][0] = priority
        if priority < previous:
            self._bubble_up(slot)
        else:
            self._bubble_down(slot)

    def _delete_slot(self, slot):
        last_slot = len(self._slots) - 1
        if slot != last_slot:
            self._exchange(slot, last_slot)
        _, _, key = self._slots.pop()
        del self._slot_of[key]
        if slot < len(self._slots):
            # The entry moved into the hole may need to go up or down; at most
            # one of these calls actually moves it.
            self._bubble_up(slot)
            self._bubble_down(slot)

    def _ranks_before(self, first, second):
        return self._slots[first][:2] < self._slots[second][:2]

    def _exchange(self, first, second):
        slots = self._slots
        slots[first], slots[second] = slots[second], slots[first]
        self._slot_of[slots[first][2]] = first
        self._slot_of[slots[second][2]] = second

    def _bubble_up(self, slot):
        while slot > 0:
            parent = (slot - 1) // 2
            if not self._ranks_before(slot, parent):
                break
            self._exchange(slot, parent)
            slot = parent

    def _bubble_down(self, slot):
        size = len(self._slots)
        while True:
            winner = slot
            for child in (2 * slot + 1, 2 * slot + 2):
                if child < size and self._ranks_before(child, winner):
                    winner = child
            if winner == slot:
                break
            self._exchange(slot, winner)
            slot = winner
